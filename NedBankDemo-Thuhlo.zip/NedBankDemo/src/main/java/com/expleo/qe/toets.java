package com.expleo.qe;


import java.io.*;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.Scanner;
import java.util.concurrent.TimeUnit;


public class toets
{

    static File testData = new File("testData.txt");

    public static void main(String[] args) throws ParseException {

        ArrayList<DataModel> arData = new ArrayList<>();
        int emailCountOld, emailCountNew;
        String emailOld, newEmail;
        arData = readTextFile();


        System.out.println(arData.get(2).getEmailAddress());
        System.out.println(arData.get(2).getEmailAddress().indexOf("p"));
        System.out.println(arData.get(2).getEmailAddress().indexOf("@"));
        System.out.println(arData.get(2).getEmailAddress().substring(7,8));


        emailCountOld = Integer.parseInt(arData.get(2).getEmailAddress().substring(7,8));

        emailOld = arData.get(2).getEmailAddress();
        System.out.println("Last email " + emailOld);

        emailCountNew = emailCountOld + 1;
        newEmail = emailOld.replace(emailCountOld+"".trim(),emailCountNew+"".trim());
        System.out.println("New Email " + newEmail);
        arData.get(2).setEmailAddress(newEmail);
        System.out.println(arData.get(2).getEmailAddress());
        writeDataBack(arData);


        //arData.get(3).setEmailAddress();

    }

    public static void writeDataBack(ArrayList<DataModel> arData)
    {
        DataModel objData;

        try
        {
            PrintWriter writter = new PrintWriter(testData);
            for(int i = 0; i < arData.size(); i++)
            {
                objData = arData.get(i);
                writter.println(objData.getGender() + "," + objData.getFirstName() + "," + objData.getLastName() +
                        "," + objData.getDateOfBirthDay() + "," + objData.getDateOfBirthMonth() + "," +
                        objData.getDateOfBirthYear() + "," + objData.getEmailAddress() + "," + objData.getCompanyName()
                + "," + objData.getNewsLetter() + "," + objData.getPassWord() + "," + objData.getConfirmPassword());
            }
            writter.close();
        }
        catch (IOException e)
        {
            e.getMessage();
        }
    }


    public static ArrayList<DataModel> readTextFile()
    {

        ArrayList<DataModel> arData = new ArrayList<>();
        DataModel objData;
        int counter = 0;

        if (testData.exists()) {

            String[] data;
            String fileLine;
            Scanner fileReader;
            String gender,firstname,lastName,day,month,year,emailAddress;
            String companyName,newsLetter,password,confirmPassword;

            try
            {
                fileReader = new Scanner(new FileReader(testData));
                while(fileReader.hasNextLine()) {
                    fileLine = fileReader.nextLine();
                    data = fileLine.split(",");
                    gender = data[0];
                    firstname = data[1];
                    lastName = data[2];
                    day = data[3];
                    month = data[4];
                    year = data[5];
                    emailAddress = data[6];
                    companyName = data[7];
                    newsLetter = data[8];
                    password = data[9];
                    confirmPassword = data[10];
                    objData = new DataModel(gender, firstname, lastName, day, month, year, emailAddress,
                            companyName, newsLetter, password, confirmPassword);
                    arData.add(objData);
                }
                fileReader.close();
            }
            catch (FileNotFoundException e)
            {}
            catch (ArrayIndexOutOfBoundsException e)
            {}
        }
        return arData;
    }
}