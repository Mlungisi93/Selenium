package com.expleo.qe.StepDefenition;

import com.expleo.qe.Steps.LogInSteps;
import com.expleo.qe.Steps.NavigationSteps;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.thucydides.core.annotations.Steps;

public class LoginStepDef
{
    String expectedPageOutput = "nopCommerce demo store. Login1";
    String userName = "tjMoabi@sqs.com";
    String password = "password";
    String confirmPage = "My account";

    @Steps
    LogInSteps logInSteps;

    @Steps
    NavigationSteps navigationSteps;

    @Given("^I navigate to homepage$")
    public void iNavigateToHomepage()
    {
        logInSteps.openBrowser();
    }

    @And("^click on the log-in link$")
    public void clickOnTheLogInLink()
    {
        navigationSteps.clickLogInOrOut();
        logInSteps.assertLoginpage(expectedPageOutput);
    }

    @When("^enter valid <username> and <password>$")
    public void enterValidUsernameAndPassword()
    {//TODO ask if this is quality
        logInSteps.logIn(userName, password);
    }

    @Then("^I should be logged into the system$")
    public void iShouldBeLoggedIntoTheSystem() throws InterruptedException {

        navigationSteps.message(navigationSteps.validateLogIn(confirmPage));

    }
}
