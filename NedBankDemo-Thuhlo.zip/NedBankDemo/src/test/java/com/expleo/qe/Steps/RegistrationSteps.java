package com.expleo.qe.Steps;

import com.expleo.qe.DataModel;
import com.expleo.qe.PageObjects.RegistrationPageobject;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.annotations.Steps;
import org.openqa.selenium.NoSuchElementException;
import org.yecht.Data;

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;

public class RegistrationSteps
{
    RegistrationPageobject registrationPageobject;


    @Step("Launch Browser")
    public void openBrowser()
    {
        registrationPageobject.openBrowser();
    }


    @Step("Register new client\n{1}\n{2}\n{3}\n{4}\n{5}\n{6}\n{7}\n{8}\n{9}\n{10}\n")
    public void registerNewClient(String gender, String firstname, String lastname, String dateOfBirthDay,
                                  String dateOfBirthMonth, String dateOfBirthYear, String emailAddress,
                                  String companyName, boolean newsLetter, String password, String confirmPassword)
    {
        try {


            if (gender.equalsIgnoreCase("male")) {
                registrationPageobject.selectGenderMale();
            } else if (gender.equalsIgnoreCase("female")) {
                registrationPageobject.selectGenderFemale();
            }

            registrationPageobject.enterFirstname(firstname);
            registrationPageobject.enterLastname(lastname);
            registrationPageobject.selectDateOfBirthDay(dateOfBirthDay);
            registrationPageobject.selectDatOfBirthMonth(dateOfBirthMonth);
            registrationPageobject.selectDateOfBirthYear(dateOfBirthYear);
            registrationPageobject.enterEmail(emailAddress);
            registrationPageobject.enterCOmpanyName(companyName);

            if (newsLetter) {
                registrationPageobject.checkNewsLetter();
            }

            registrationPageobject.enterPassword(password);
            registrationPageobject.confirmPassword(confirmPassword);
            //registrationPageobject.clickRegisterButton();
        }catch (IllegalArgumentException e)
        {
            System.out.println(e.getMessage());
        }
    }


    @Step("User Click Register")
    public void clickRegisterButton() throws InterruptedException {
        registrationPageobject.clickRegisterButton();
        Thread.sleep(2000);
    }

    @Step("Are we on the Registration Page {0}")
    public void confirmRegistrationPage(String expected)
    {
        registrationPageobject.areWeOnTheRegistrationPage(expected);
    }

    @Step
    public void assertNoEmailErrorMessage()
    {
        String recievedMessage;
        try
        {
            recievedMessage = registrationPageobject.emailError();
            assertThat("Error :" + recievedMessage,recievedMessage,is(equalTo("null")));
            recievedMessage = "Correct E-mail Address passed";
        }
        catch (AssertionError ex)
        {
            recievedMessage = "In-Correct E-mail Address ";
        }
        catch (NoSuchElementException e)
        {
            recievedMessage = "Email Address Field ot found";
        }

    }

    @Step()
    public String assertRegistration(String expected)
    {//TODO added recievedMessage nad returned String
        String recievedMessage;
        try
        {
            assertThat("Registration Falied", expected,
                    is(equalTo(registrationPageobject.regSuccess())));
            recievedMessage = registrationPageobject.regSuccess() + " Successfully   >> As Expected";
        }
        catch (AssertionError e)
        {
            recievedMessage = "Client Registration Failed >> Not Expected";
        }
        catch (NoSuchElementException e)
        {
            recievedMessage = "Client Registration Failed - Element not found >> Not Expected";
        }
        return recievedMessage;
    }

    @Step
    public String assertEmailErrorMessage() throws InterruptedException {
        String recievedMessage;
        try
        {
            recievedMessage = registrationPageobject.emailError();
            assertThat("Error : " + recievedMessage, recievedMessage,is(not("null")));
            recievedMessage += "  >> As Expected";

        }
        catch (AssertionError ex)
        { //TODO fix or check message is dsiplayed in report
            recievedMessage = "Invalid E-mail Address " + registrationPageobject.emailError();
        }
        Thread.sleep(1000);
        return recievedMessage;
    }


    @Step("{0}")
    public void message(String message){}

    public void manageData()
    {
        ArrayList<DataModel> arData = new ArrayList<>();
        int emailCountOld, emailCountNew;
        String emailOld, newEmail;

        arData = readTextFile();
        emailCountOld = Integer.parseInt(arData.get(2).getEmailAddress().substring(7,8));

        emailOld = arData.get(2).getEmailAddress();
        System.out.println("Last email " + emailOld);

        emailCountNew = emailCountOld + 1;
        newEmail = emailOld.replace(emailCountOld+"".trim(),emailCountNew+"".trim());
        System.out.println("New Email " + newEmail);
        arData.get(2).setEmailAddress(newEmail);
        System.out.println(arData.get(2).getEmailAddress());
        writeDataBack(arData);
    }

    public static void writeDataBack(ArrayList<DataModel> arData)
    {
        DataModel objData;
        File testData = new File("testData.txt");
        try
        {
            PrintWriter writter = new PrintWriter(testData);
            for(int i = 0; i < arData.size(); i++)
            {
                objData = arData.get(i);
                writter.println(objData.getGender() + "," + objData.getFirstName() + "," + objData.getLastName() +
                        "," + objData.getDateOfBirthDay() + "," + objData.getDateOfBirthMonth() + "," +
                        objData.getDateOfBirthYear() + "," + objData.getEmailAddress() + "," + objData.getCompanyName()
                        + "," + objData.getNewsLetter() + "," + objData.getPassWord() + "," + objData.getConfirmPassword());
            }
            writter.close();
        }
        catch (IOException e)
        {
            e.getMessage();
        }
    }

    public static ArrayList<DataModel> readTextFile()
    {
        File testData = new File("testData.txt");
        ArrayList<DataModel> arData = new ArrayList<>();
        DataModel objData;
        String message;

        if (testData.exists()) {

            String[] data;
            String fileLine;
            Scanner fileReader;
            String gender,firstname,lastName,day,month,year,emailAddress;
            String companyName,newsLetter,password,confirmPassword;

            try
            {
                fileReader = new Scanner(new FileReader(testData));
                while(fileReader.hasNextLine()) {
                    fileLine = fileReader.nextLine();
                    data = fileLine.split(",");
                    gender = data[0];
                    firstname = data[1];
                    lastName = data[2];
                    day = data[3];
                    month = data[4];
                    year = data[5];
                    emailAddress = data[6];
                    companyName = data[7];
                    newsLetter = data[8];
                    password = data[9];
                    confirmPassword = data[10];
                    objData = new DataModel(gender, firstname, lastName, day, month, year, emailAddress,
                            companyName, newsLetter, password, confirmPassword);
                    arData.add(objData);
                }
                fileReader.close();
                message = "Test Data Management - Successful";
            }
            catch (FileNotFoundException e)
            {
                message = "Test Data Management - Not Successful";
            }
            catch (ArrayIndexOutOfBoundsException e)
            {
                message = "Test Data Management - Not Successful";
            }
        }
        return arData;
    }
}
