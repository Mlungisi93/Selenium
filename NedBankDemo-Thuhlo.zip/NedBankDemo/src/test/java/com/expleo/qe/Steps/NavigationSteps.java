package com.expleo.qe.Steps;

import com.expleo.qe.PageObjects.NavigationObject;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.annotations.Steps;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.concurrent.TimeUnit;

import static net.thucydides.core.webdriver.ThucydidesWebDriverSupport.getDriver;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;

public class NavigationSteps
{
    NavigationObject navigationObject;

    @Step("Click on Register")
    public void clickRegister()
    {
        navigationObject.linkRegister();
    }

    @Step("Click on login or logout")
    public void clickLogInOrOut()
    {
        navigationObject.linkLogInOrOut();

    }

    @Step("Open the Browser")
    public void openBrowser()
    {
        navigationObject.openBrowser();
    }

    @Step("Navigate to Computers sub Menu Desktop")
    public void navigateToSubComputerDesktop()
    {
        navigationObject.subComputerDesktop(getDriver());
    }

    @Step("Select Build YourOwn Computer")
    public void buildYourOwnComputer()
    {
        navigationObject.buildYourComputer();
    }

    @Step("Navigate to Shopping Cart")
    public void navigateToCart()
    {
        navigationObject.linkCart();
    }

    @Step("Validate Page {0}\n")
    public String validateLogIn(String expected) throws InterruptedException
    {
        String recievedMessage = "\nCorrect Page Found";
        System.out.println("In the validate ...");
        try
        {
            Thread.sleep(1000);
            assertThat("Incorrect Page ", expected, is(navigationObject.validateLogin()));
        }
        catch (AssertionError e)
        {
           //recievedMessage = "Incorrect Page :" + e.getMessage();
            recievedMessage = "User Login Failed  >> Not Expected";
        }
        return recievedMessage;
    }


    public String assertFinalCheckoutPrice(String expected)
    {
        String message;
        try{
            navigationObject.pageScrollDown();
            System.out.println("Expected ::: " + expected);

            //assertThat("Checkout price invalid",true,is(equalTo(navigationObject.getCartTotalPrice().trim())));
            System.out.println(navigationObject.getCartTotalPrice().equalsIgnoreCase(expected));
            assertThat(navigationObject.getCartTotalPrice(),equalTo(expected));
            message = "Final Price is as Expected " + expected;

        }
        catch (AssertionError e)
        {
            message = "Final Price is Incorrect Expected : " + expected + " \nbut Found : " + navigationObject.getCartTotalPrice();
            //expected+=" is not equal to "+ navigationObject.getCartTotalPrice();
       }catch (StaleElementReferenceException e){
            message = "Elements Error in Navigation Steps :: "+ e.getMessage();//navigationObject.getCartTotalPrice();
       }
        return  message;
    }

    public String assertWeAreOnRegisterPage(String expected)
    {
        String recievedMessage;

        try
        {
            assertThat(expected,is(equalTo(expected)));
            recievedMessage = "Registration Page Found";
        }
        catch (AssertionError e)
        {
            recievedMessage = "Registration Page Not Found";
        }
        return recievedMessage;
    }

    @Step("{0}")
    public void message(String message){}

    public void scrollUp()
    {
        navigationObject.pageScrollUp();
    }

    @Step
    public void manageTestData()
    {

           // new WebDriverWait(getDriver(),3).until(ExpectedConditions.elementToBeClickable(navigationObject.removeFromCart()));
            //System.out.println("in cart");
            navigationObject.removeFromCart();
            getDriver().manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

        //openBrowser();
        //clickLogInOrOut();
        //navigateToCart();

    }

}
